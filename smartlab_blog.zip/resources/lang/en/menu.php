<?php

return [
    'first_item' => 'What we do',
    'second_item' => 'Who we are',
    'third_item' => 'Join us',
    'fourth_item' => 'Blog',
    'fifth_item' => 'Contact',
    'sixth_item' => 'Admins',
    'seventh_item' => 'Blogs',
    'eight_item' => 'Logout',
    'english_language' => 'En',
    'german_language' => 'De',
    'bosnian_language' => 'Ba'
];
