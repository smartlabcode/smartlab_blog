<?php

return [
    'first_item' => 'Sta mi radimo',
    'second_item' => 'Ko smo mi',
    'third_item' => 'Pridruzite nam se',
    'fourth_item' => 'Blog',
    'fifth_item' => 'Kontakt',
    'sixth_item' => 'Admini',
    'seventh_item' => 'Blogovi',
    'eight_item' => 'Izloguj se',
    'english_language' => 'En',
    'german_language' => 'De',
    'bosnian_language' => 'Ba'
];
