<?php

return [

    'heading' => 'Erste Seite',
    'formName' => 'Vorname',
    'formSurname' => 'Nachname',
    'formSubject' => 'Betreff',
    'formEmail' => 'Email',
    'formMessage' => 'Nachricht'

];
