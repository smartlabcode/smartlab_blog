<?php

return [

    'heading' => 'Glavna stranica'
    'formName' => 'Ime',
    'formSurname' => 'Prezime',
    'formSubject' => 'Predmet',
    'formEmail' => 'Email',
    'formMessage' => 'Poruka'

];