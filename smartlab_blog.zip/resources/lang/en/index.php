<?php

return [

    'heading' => 'Main page',
    'formName' => 'Name',
    'formSurname' => 'Surname',
    'formSubject' => 'Subject',
    'formEmail' => 'Email',
    'formMessage' => 'Message'

];
