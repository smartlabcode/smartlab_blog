<?php

return [
    'first_item' => 'Was machen wir',
    'second_item' => 'Wer sind wir',
    'third_item' => 'Komm mit uns',
    'fourth_item' => 'Blog',
    'fifth_item' => 'Kontakt',
    'sixth_item' => 'Administratoren',
    'seventh_item' => 'Blogs',
    'eight_item' => 'Ausloggen',
    'english_language' => 'En',
    'german_language' => 'De',
    'bosnian_language' => 'Ba'
];
