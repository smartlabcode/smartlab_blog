<?php return array (
  'Illuminate\\Auth\\Events\\Registered' => 
  array (
    0 => 'Illuminate\\Auth\\Listeners\\SendEmailVerificationNotification',
  ),
);